# SE3_TRJ_plot
MATLAB script plotting SE3 pose with coordinates.
Run "SE3_TRJ_Plotting.m" script and you will be able to see the following screen from your MATLAB.
![screenShot](https://drive.google.com/uc?export=view&id=0B-0CTsFowMRVXzhmVFBNVmZJNnc)



