* Sept 29, 2017
* Jungwon Kang


================================================================================================================
## Introduction
================================================================================================================
[MFCApplication2_20170929_1] is a testing application with a library for algebraic-based (multi) trilateration.

It is implemented in visual studio 2015 and with opencv 2.4.13.2 (for matrix computation).

We refered to the paper
A. Norrdine, "An Algebraic Solution to the Multilateration Problem,"
2012 International Conference on Indoor Positioning and Indoor Navigation.

The author of the paper opened his matlab code:
https://www.mathworks.com/matlabcentral/fileexchange/54680-trilateration-code
(Trilateration_public_matlab.zip here)

[MFCApplication2_20170929_1] is a c++ version of the code. 
However, we modified some part of the algorithm:
  (1) Producing more solution candidates
  (2) Inverting z if z<0
  (3) Changing error term (unweighted -> weighted)


================================================================================================================
## Files
================================================================================================================
The class 'CLibTrilateration' is a library for trilateration.
It is written in [LibTrilateration.h] & [LibTrilateration.cpp].

The other files are just for MFC application, not for the algorithm.


================================================================================================================
## Hierarchy in the class 'CLibTrilateration'
================================================================================================================
run_tri_recursive_np4() 	: corresponds to [IPINTrilaterationExampleB.m]
	_rec_tri_npX()		: corresponds to [RecTrilateration.m] (np > 3 case)
		_rec_tri_np3()	: corresponds to [RecTrilateration.m] (np == 3 case)
		_lsrec()	: corresponds to [lsrec.m]


================================================================================================================
## Using the class 'CLibTrilateration'
================================================================================================================
The current 'CLibTrilateration' assumes that there are four static stations.

You can get xyz position of the receiver by calling the following function:
  int CLibTrilateration::run_tri_recursive_np4(	const double* Mat_pnt_ref, 
						const double* Vec_dist_mea, 
						const double* Vec_weight, 
						const int Num_pnt_ref, 
						double* Vec_out)

The detailed instruction of how to call CLibTrilateration::run_tri_recursive_np4() is given in the function
  test_accuracy_tri_num_pnt_ref4()




The End-of-File
